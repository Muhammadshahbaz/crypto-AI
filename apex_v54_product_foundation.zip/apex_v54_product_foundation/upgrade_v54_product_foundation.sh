#!/bin/bash
set -e
cd /opt/apex-v4/apex_v4_binance

echo "Applying APEX v5.4 product foundation..."

mkdir -p data app/admin app/dashboard app/paper

python -m py_compile app/admin/service.py app/admin/routes.py app/admin/web.py app/dashboard/web.py

if ! grep -q "from app.admin.routes import router as admin_router" app/main.py; then
python3 - <<'PY'
from pathlib import Path
p=Path("app/main.py")
s=p.read_text()
s=s.replace("from app.dashboard.web import dashboard_page", "from app.dashboard.web import dashboard_page\nfrom app.admin.web import admin_page\nfrom app.admin.routes import router as admin_router")
s=s.replace("app = FastAPI(title=settings.app_name)", "app = FastAPI(title=settings.app_name)\napp.include_router(admin_router)")
if "@app.get('/admin')" not in s and '@app.get("/admin")' not in s:
    marker="@app.get('/dashboard')\nasync def dashboard():\n    return dashboard_page()\n"
    s=s.replace(marker, marker+"\n@app.get('/admin')\nasync def admin():\n    return admin_page()\n")
p.write_text(s)
PY
fi

python -m py_compile app/main.py app/admin/service.py app/admin/routes.py app/admin/web.py app/dashboard/web.py

git add app/admin app/dashboard app/main.py data || true
git commit -m "Add APEX v5.4 product foundation and professional UI" || true

docker compose down
docker compose up -d --build
docker compose ps
docker compose logs --tail=60

echo "Done."
echo "Dashboard: http://34.148.133.181:8000/dashboard"
echo "Admin:     http://34.148.133.181:8000/admin"
