from fastapi.responses import HTMLResponse

DASHBOARD_HTML = """
<!doctype html>
<html lang="en">
<head>
<title>APEX v5.4 Command Center</title>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root{--bg:#050816;--card:#0b1220;--card2:#101827;--line:#1e293b;--text:#e5e7eb;--muted:#94a3b8;--blue:#3b82f6;--green:#22c55e;--red:#ef4444;--amber:#f59e0b;--cyan:#22d3ee}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 15% -10%,rgba(59,130,246,.25),transparent 34%),radial-gradient(circle at 90% 0,rgba(34,211,238,.12),transparent 30%),var(--bg);color:var(--text);font-family:Inter,system-ui,Arial}
.wrap{max-width:1580px;margin:auto;padding:28px}.top{display:flex;justify-content:space-between;gap:20px;align-items:flex-start}.brand h1{font-size:38px;margin:0;letter-spacing:-.05em}.brand p{color:var(--muted);margin:8px 0 0}.nav{display:flex;gap:10px;flex-wrap:wrap}
a.btn,button{background:linear-gradient(135deg,var(--blue),#1d4ed8);border:0;color:white;text-decoration:none;border-radius:14px;padding:12px 16px;font-weight:900;cursor:pointer}.dark{background:#111827!important;border:1px solid var(--line)!important}.danger{background:linear-gradient(135deg,#ef4444,#991b1b)!important}
.pills{display:flex;gap:10px;flex-wrap:wrap;margin-top:15px}.pill{background:rgba(15,23,42,.9);border:1px solid #26364f;color:#bfdbfe;border-radius:999px;padding:9px 13px;font-weight:900;font-size:13px}.dot{display:inline-block;width:10px;height:10px;background:var(--green);border-radius:99px;margin-right:8px;box-shadow:0 0 18px var(--green)}
.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px;margin-top:22px}.card{background:linear-gradient(180deg,rgba(15,23,42,.95),rgba(7,12,25,.98));border:1px solid var(--line);border-radius:24px;padding:20px;box-shadow:0 24px 70px rgba(0,0,0,.28)}.kpi{grid-column:span 3}.wide{grid-column:span 8}.side{grid-column:span 4}.half{grid-column:span 6}.full{grid-column:1/-1}
.label{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.08em;font-weight:900}.big{font-size:36px;font-weight:950;margin-top:8px;letter-spacing:-.05em}.small{color:var(--muted);font-size:13px;margin-top:8px}.good{color:var(--green)}.bad{color:var(--red)}.warn{color:var(--amber)}.cyan{color:var(--cyan)}h2{margin:0 0 14px;font-size:22px;letter-spacing:-.03em}
table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid var(--line);padding:12px 10px;text-align:left;font-size:13px}th{color:#cbd5e1;background:rgba(15,23,42,.7);text-transform:uppercase;font-size:11px;letter-spacing:.08em}
pre{white-space:pre-wrap;background:#020617;border:1px solid var(--line);border-radius:16px;padding:14px;color:#cbd5e1;max-height:330px;overflow:auto}.modules{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.module{background:#020617;border:1px solid var(--line);border-radius:18px;padding:15px}
@media(max-width:1100px){.top{display:block}.nav{margin-top:16px}.grid,.modules{grid-template-columns:1fr}.kpi,.wide,.side,.half{grid-column:1/-1}}
</style>
</head>
<body><div class="wrap">
<div class="top"><div class="brand"><h1>APEX v5.4 Trading Command Center</h1><p>Professional multi-exchange AI trading platform: monitor, scan, risk-manage and control paper/demo/live operations.</p><div class="pills"><span class="pill"><span class="dot"></span>API Online</span><span id="modePill" class="pill">Mode</span><span id="exchangePill" class="pill">Exchange</span><span id="botPill" class="pill">Bot</span></div></div><div class="nav"><button onclick="scan()">Run Scan</button><button class="dark" onclick="updatePaper()">Update Trades</button><a class="btn dark" href="/admin">Admin</a><a class="btn dark" href="/docs">API Docs</a></div></div>
<div class="grid">
<div class="card kpi"><div class="label">Equity</div><div class="big" id="equity">$0</div><div class="small">Paper/demo account equity</div></div>
<div class="card kpi"><div class="label">Total PnL</div><div class="big" id="pnl">$0</div><div class="small">Closed trade PnL</div></div>
<div class="card kpi"><div class="label">Win Rate</div><div class="big" id="winrate">0%</div><div class="small">Closed winners ratio</div></div>
<div class="card kpi"><div class="label">Open Trades</div><div class="big" id="open">0</div><div class="small">Active paper positions</div></div>
<div class="card wide"><h2>Equity Curve</h2><canvas id="curve" height="112"></canvas></div>
<div class="card side"><h2>Account Snapshot</h2><pre id="account">Loading...</pre></div>
<div class="card half"><h2>Paper Trades</h2><table><thead><tr><th>ID</th><th>Pair</th><th>Side</th><th>Status</th><th>Entry</th><th>PnL</th></tr></thead><tbody id="trades"></tbody></table></div>
<div class="card half"><h2>Live Signal Feed</h2><pre id="lastscan">No scan yet.</pre></div>
<div class="card full"><h2>Product Modules</h2><div class="modules"><div class="module"><div class="label">Exchange Layer</div><p class="small">Bitget now, Binance/Bybit/OKX/KuCoin ready as adapters.</p></div><div class="module"><div class="label">AI Layer</div><p class="small">OpenAI, Claude, DeepSeek, Gemini consensus planning.</p></div><div class="module"><div class="label">Risk Layer</div><p class="small">Kill switch, max loss, max leverage, live unlock safety.</p></div><div class="module"><div class="label">SaaS Layer</div><p class="small">Admin, user accounts, key vault, subscriptions next.</p></div></div></div>
</div></div>
<script>
let chart; async function j(u,o){const r=await fetch(u,o); if(!r.ok) throw new Error(u+' '+r.status); return await r.json()} function money(v){return '$'+Number(v||0).toFixed(2)}
async function load(){const [sum,cfg,health,admin,acct,bot]=await Promise.all([j('/api/dashboard/summary'),j('/api/config'),j('/health'),j('/api/admin/settings'),j('/api/admin/account-summary'),j('/api/admin/bot/status')]); const mode=(admin.exchange?.trading_mode||'paper').toUpperCase(), ex=admin.exchange?.active_exchange||cfg.exchange||'unknown'; modePill.textContent='MODE: '+mode; exchangePill.textContent='Exchange: '+ex; botPill.textContent='Bot: '+(bot.status||'stopped').toUpperCase(); equity.textContent=money(sum.equity); pnl.textContent=money(sum.total_pnl); pnl.className='big '+(Number(sum.total_pnl)>=0?'good':'bad'); winrate.textContent=(sum.win_rate||0)+'%'; open.textContent=sum.open_trades||0; account.textContent=JSON.stringify({health,config:cfg,account:acct,risk:admin.risk},null,2); if(chart)chart.destroy(); chart=new Chart(document.getElementById('curve'),{type:'line',data:{labels:(sum.equity_curve||[]).map(x=>x.trade),datasets:[{label:'Equity',data:(sum.equity_curve||[]).map(x=>x.equity),tension:.35,borderWidth:3}]},options:{plugins:{legend:{labels:{color:'#e5e7eb'}}},scales:{x:{ticks:{color:'#94a3b8'},grid:{color:'rgba(148,163,184,.08)'}},y:{ticks:{color:'#94a3b8'},grid:{color:'rgba(148,163,184,.08)'}}}}}); const t=await j('/api/paper-trades'); trades.innerHTML=t.length?t.map(x=>`<tr><td>${x.id}</td><td>${x.pair}</td><td>${x.direction}</td><td>${x.status}</td><td>${Number(x.entry).toFixed(4)}</td><td class="${Number(x.pnl_usd)>=0?'good':'bad'}">${money(x.pnl_usd)}</td></tr>`).join(''):'<tr><td colspan="6" class="small">No paper trades yet. Run scan or add test trade later.</td></tr>'}
async function scan(){lastscan.textContent='Scanning...'; const r=await j('/api/scan-once',{method:'POST'}); lastscan.textContent=JSON.stringify(r,null,2); load()} async function updatePaper(){const r=await j('/api/paper/update',{method:'POST'}); lastscan.textContent=JSON.stringify(r,null,2); load()} load(); setInterval(load,10000)
</script></body></html>
"""
def dashboard_page():
    return HTMLResponse(DASHBOARD_HTML)
