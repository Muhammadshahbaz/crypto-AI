import json
from pathlib import Path
from datetime import datetime
from app.config import settings

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
SETTINGS_FILE = DATA_DIR / "admin_settings.json"

DEFAULTS = {
    "exchange": {
        "active_exchange": getattr(settings, "exchange", "bitget"),
        "trading_mode": "paper",
        "live_trading_enabled": False,
        "bitget": {"enabled": True, "mode": "paper", "api_key": "", "api_secret": "", "api_password": ""},
        "binance": {"enabled": False, "mode": "paper", "api_key": "", "api_secret": ""},
        "bybit": {"enabled": False, "mode": "paper"},
        "okx": {"enabled": False, "mode": "paper"},
        "kucoin": {"enabled": False, "mode": "paper"},
    },
    "risk": {
        "max_risk_per_trade": getattr(settings, "max_risk_per_trade", 0.005),
        "max_daily_loss": getattr(settings, "max_daily_loss", 0.03),
        "max_weekly_loss": getattr(settings, "max_weekly_loss", 0.08),
        "max_concurrent_trades": getattr(settings, "max_concurrent_trades", 3),
        "default_leverage": getattr(settings, "default_leverage", 1),
        "max_leverage": getattr(settings, "max_leverage", 3),
        "kill_switch_enabled": False,
    },
    "ai": {
        "openai_enabled": getattr(settings, "ai_openai_enabled", False),
        "claude_enabled": getattr(settings, "ai_claude_enabled", False),
        "deepseek_enabled": False,
        "gemini_enabled": False,
        "openai_api_key": "",
        "anthropic_api_key": "",
        "deepseek_api_key": "",
        "gemini_api_key": "",
        "consensus_required": True,
    },
    "notifications": {
        "telegram_enabled": False,
        "telegram_bot_token": "",
        "telegram_chat_id": "",
        "email_enabled": False,
        "discord_enabled": False,
    },
    "bot": {
        "status": "stopped",
        "auto_scan_enabled": False,
        "scan_interval_seconds": getattr(settings, "scan_interval_seconds", 60),
        "last_action": None,
        "last_action_at": None,
    },
    "product": {
        "version": "5.4",
        "name": "APEX AI Trading Platform",
        "environment": getattr(settings, "env", "dev"),
    },
}

def _deep_merge(base, incoming):
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base

def _load():
    if SETTINGS_FILE.exists():
        try:
            data = json.loads(SETTINGS_FILE.read_text())
            return _deep_merge(DEFAULTS.copy(), data)
        except Exception:
            return DEFAULTS.copy()
    _save(DEFAULTS.copy())
    return DEFAULTS.copy()

def _save(data):
    SETTINGS_FILE.write_text(json.dumps(data, indent=2))
    return data

async def get_all_settings():
    return _load()

async def save_admin_settings(data=None):
    current = _load()
    if isinstance(data, dict):
        _deep_merge(current, data)
    _save(current)
    return {"ok": True, "settings": current}

async def get_exchange_settings():
    return _load()["exchange"]

async def save_exchange_settings(data=None):
    current = _load()
    if isinstance(data, dict):
        _deep_merge(current["exchange"], data)
    _save(current)
    return {"ok": True, "exchange": current["exchange"]}

async def get_risk_settings():
    return _load()["risk"]

async def save_risk_settings(data=None):
    current = _load()
    if isinstance(data, dict):
        _deep_merge(current["risk"], data)
    _save(current)
    return {"ok": True, "risk": current["risk"]}

async def get_ai_settings():
    return _load()["ai"]

async def save_ai_settings(data=None):
    current = _load()
    if isinstance(data, dict):
        _deep_merge(current["ai"], data)
    _save(current)
    return {"ok": True, "ai": current["ai"]}

async def get_notification_settings():
    return _load()["notifications"]

async def save_notification_settings(data=None):
    current = _load()
    if isinstance(data, dict):
        _deep_merge(current["notifications"], data)
    _save(current)
    return {"ok": True, "notifications": current["notifications"]}

async def list_exchanges():
    ex = _load()["exchange"]
    return [
        {"name": name, "enabled": bool(ex.get(name, {}).get("enabled", False)), "mode": ex.get(name, {}).get("mode", "paper"), "active": ex.get("active_exchange") == name}
        for name in ["bitget", "binance", "bybit", "okx", "kucoin"]
    ]

async def get_trading_mode():
    ex = _load()["exchange"]
    return {"mode": ex.get("trading_mode", "paper"), "live_trading_enabled": bool(ex.get("live_trading_enabled", False))}

async def save_trading_mode(data=None):
    current = _load()
    if isinstance(data, dict):
        mode = data.get("mode", "paper")
        live_enabled = bool(data.get("live_trading_enabled", False))
        if mode == "live" and not live_enabled:
            return {"ok": False, "message": "Live mode requires explicit live trading unlock."}
        current["exchange"]["trading_mode"] = mode
        current["exchange"]["live_trading_enabled"] = live_enabled
        for ex in ["bitget", "binance", "bybit", "okx", "kucoin"]:
            if ex in current["exchange"] and isinstance(current["exchange"][ex], dict):
                current["exchange"][ex]["mode"] = mode
    _save(current)
    return {"ok": True, "trading_mode": await get_trading_mode()}

async def start_bot():
    current = _load()
    current["bot"]["status"] = "running"
    current["bot"]["last_action"] = "start"
    current["bot"]["last_action_at"] = datetime.utcnow().isoformat()
    _save(current)
    return {"ok": True, "bot": current["bot"]}

async def stop_bot():
    current = _load()
    current["bot"]["status"] = "stopped"
    current["bot"]["last_action"] = "stop"
    current["bot"]["last_action_at"] = datetime.utcnow().isoformat()
    _save(current)
    return {"ok": True, "bot": current["bot"]}

async def get_bot_status():
    return _load()["bot"]

async def test_exchange_connection(exchange: str = "bitget"):
    cfg = _load()["exchange"]
    selected = cfg.get(exchange, {})
    has_key = bool(selected.get("api_key"))
    return {
        "ok": True,
        "exchange": exchange,
        "mode": cfg.get("trading_mode", "paper"),
        "api_key_present": has_key,
        "message": "Admin settings loaded. Real balance/positions require v5.5 exchange-account wiring.",
    }

async def get_account_summary():
    s = _load()
    return {
        "exchange": s["exchange"].get("active_exchange", "bitget"),
        "mode": s["exchange"].get("trading_mode", "paper"),
        "dry_run": getattr(settings, "dry_run", True),
        "equity": 1000.0,
        "available": 1000.0,
        "unrealized_pnl": 0.0,
        "positions": [],
        "orders": [],
        "note": "Paper account summary. Live exchange balance/positions will be wired after secrets are encrypted.",
    }

async def product_health():
    s = _load()
    return {
        "ok": True,
        "version": s["product"]["version"],
        "bot_status": s["bot"]["status"],
        "mode": s["exchange"]["trading_mode"],
        "active_exchange": s["exchange"]["active_exchange"],
        "live_unlocked": s["exchange"]["live_trading_enabled"],
    }
