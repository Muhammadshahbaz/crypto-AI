from fastapi import APIRouter
from app.admin.service import (
    get_all_settings, save_admin_settings,
    get_exchange_settings, save_exchange_settings,
    get_risk_settings, save_risk_settings,
    get_ai_settings, save_ai_settings,
    get_notification_settings, save_notification_settings,
    list_exchanges, test_exchange_connection,
    get_trading_mode, save_trading_mode,
    start_bot, stop_bot, get_bot_status,
    get_account_summary, product_health,
)

router = APIRouter(prefix="/api/admin", tags=["admin"])

@router.get("/settings")
async def settings():
    return await get_all_settings()

@router.post("/settings")
async def save_settings(payload: dict):
    return await save_admin_settings(payload)

@router.get("/exchange-settings")
async def exchange_settings():
    return await get_exchange_settings()

@router.post("/exchange-settings")
async def save_exchange(payload: dict):
    return await save_exchange_settings(payload)

@router.get("/risk-settings")
async def risk_settings():
    return await get_risk_settings()

@router.post("/risk-settings")
async def save_risk(payload: dict):
    return await save_risk_settings(payload)

@router.get("/ai-settings")
async def ai_settings():
    return await get_ai_settings()

@router.post("/ai-settings")
async def save_ai(payload: dict):
    return await save_ai_settings(payload)

@router.get("/notification-settings")
async def notification_settings():
    return await get_notification_settings()

@router.post("/notification-settings")
async def save_notifications(payload: dict):
    return await save_notification_settings(payload)

@router.get("/exchanges")
async def exchanges():
    return await list_exchanges()

@router.post("/test-exchange/{exchange}")
async def test_exchange(exchange: str):
    return await test_exchange_connection(exchange)

@router.get("/trading-mode")
async def trading_mode():
    return await get_trading_mode()

@router.post("/trading-mode")
async def set_trading_mode(payload: dict):
    return await save_trading_mode(payload)

@router.post("/bot/start")
async def bot_start():
    return await start_bot()

@router.post("/bot/stop")
async def bot_stop():
    return await stop_bot()

@router.get("/bot/status")
async def bot_status():
    return await get_bot_status()

@router.get("/account-summary")
async def account_summary():
    return await get_account_summary()

@router.get("/product-health")
async def admin_product_health():
    return await product_health()
